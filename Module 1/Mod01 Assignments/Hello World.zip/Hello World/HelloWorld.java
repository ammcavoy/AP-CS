/** 
 * Display "Hello World" message on the screen
 * 
 */
public class HelloWorld
{
   public static void main(String[] args)
   {
       System.out.print('\u000C');
       System.out.println("Hello World");
       System.out.println("It is a great day for programming.");
    }//end of main method
}//end of class

