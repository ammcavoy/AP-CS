
/**
 * Write a description of class questions here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class questions
{
    
    public questions()
    {
        /**
        1. A deck is a group of cards, cards are the individuals.
        
        2. 6
        
        3. String[] suits = {"Hearts","Diamonds","Spades","Clubs"};
        int[] values= {1,2,3,4,5,6,7,8,9,10,11,12,13};
        String[] ranks = {"Ace","2","3","4","5","6","7","8","9","10","Jack","Queen","King"};
        
        4. No
        */

    }

}
