
/**
 * Description for 4.03 Target Zone project
 *
 * @author (Your Name)
 * @version (The Date)
 */
import java.util.Scanner;
public class TargetZone
{
    public static void main(String[] args)
    {
        //Initialize and declare variables
        String zone = "within";				//default assumes target is within zone
        Scanner in = new Scanner(System.in);

        //Prompt user for input


        //Calculate heart rate target zone min and max


        //Determine if heart rate after exercise is not within the target zone's min and max.
        //If heart rate is below, change value of zone variable to "below".


        //If heart rate is above, change value of zone variable to "above".


        //Print two output statements
        //The first stating the heart rate target zone values.


        //The second stating if the heart rate after exercise  was within, above or below
        //the target zone. Use the variable "zone" to display the correct status.


    } //end main
}//end class TargetZone