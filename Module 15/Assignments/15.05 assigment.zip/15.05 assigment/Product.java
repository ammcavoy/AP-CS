
public interface Product 
{
    public abstract String getName();
	public abstract double getCost();
}