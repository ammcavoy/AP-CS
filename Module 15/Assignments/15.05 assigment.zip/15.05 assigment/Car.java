public class Car extends Vehicle 
{
	public Car(String name, double cost)
	{
		super(name, cost);
	}

}