public class Truck extends Vehicle 
{
	public Truck(String name, double cost)
	{
		super(name, cost);
	}
}