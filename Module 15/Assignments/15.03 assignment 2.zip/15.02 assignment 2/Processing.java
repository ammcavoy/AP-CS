/**
 
 */
public interface Processing 
{
    public abstract void doReading();
}
