
/**
 * Tester tests the BeadedJava class. 
 * 
 * �FLVS 2007
 * @author R. Enger 
 * @version 5/10/07
 */
public class Tester
{


    public static void main(String []args)
	{
		
	    BeadedJean pair1 = new BeadedJean(3, 20);
	    
	    pair1.design();
	    System.out.println(pair1);
    }
}
