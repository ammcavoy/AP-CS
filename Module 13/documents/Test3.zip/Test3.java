
/**
 * test3 demo
 * 
 * �FLVS 2007
 * @author R. Enger 
 * @version 5/5/2007
 */
public class Test3
{
	public static void main(String []args)
	{
           Rectangle2 one = new Rectangle2(5, 20);
           Box2 two = new Box2(4, 10, 5);
	   
	      System.out.println(one);
	      System.out.println(two);
	 }
}
