public class Equilateral extends Triangle 
{
    public Equilateral(double side)
    {
        super(side, side, side);
    }
}
