public class IsoscelesRight extends Triangle
{
    IsoscelesRight(double side)
    {
        super(side, side, (side * Math.sqrt(2)));
    }
}